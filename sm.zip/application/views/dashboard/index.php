<h1>Dashboard</h1><br>
<a href="<?php echo site_url("dashboard/logout"); ?>">Logout</a>